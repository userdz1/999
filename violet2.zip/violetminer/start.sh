chmod +x violetminer
./violetminer --pool turtlecoin.herominers.com:10381 --username TRTLv1z1BNAJjVzpdKkFNnHRiJ4hebCR2S4rtnFcJi4S4ujqcdMcMqJX9vamnUcG35BkQy6VfwUy5CsV9YNomioPGGyVhJTqJE6 --password workerg1 --algorithm turtlecoin
